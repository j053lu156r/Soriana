sap.ui.define([
    "sap/ui/model/json/JSONModel",
    "demo/controllers/BaseController",
    "sap/ui/core/mvc/Controller"
], function (JSONModel, Controller) {
    "use strict";

    var oModel = new this.Remissions();

    return Controller.extend("demo.controllers.Remissions.Detail", {
        onInit: function () {
            var oExitButton = this.getView().byId("exitFullScreenBtn"),
                oEnterButton = this.getView().byId("enterFullScreenBtn");

            this.oRouter = this.getOwnerComponent().getRouter();
            this.oModel = this.getOwnerComponent().getModel();

            this.oRouter.getRoute("detailRemission").attachPatternMatched(this._onDocumentMatched, this);

            [oExitButton, oEnterButton].forEach(function (oButton) {
                oButton.addEventDelegate({
                    onAfterRendering: function () {
                        if (this.bFocusFullScreenButton) {
                            this.bFocusFullScreenButton = false;
                            oButton.focus();
                        }
                    }.bind(this)
                });
            }, this);
        },
        handleItemPress: function (oEvent) {
            var oNextUIState = this.getOwnerComponent().getHelper().getNextUIState(2),
                supplierPath = oEvent.getSource().getBindingContext("tableItemsCfdi").getPath(),
                supplier = supplierPath.split("/").slice(-1).pop();

        },
        handleFullScreen: function () {
            this.bFocusFullScreenButton = true;
            var sNextLayout = this.oModel.getProperty("/actionButtonsInfo/midColumn/fullScreen");
            this.oRouter.navTo("detailRemission", { layout: sNextLayout, document: this._document });
        },
        handleExitFullScreen: function () {
            this.bFocusFullScreenButton = true;
            var sNextLayout = this.oModel.getProperty("/actionButtonsInfo/midColumn/exitFullScreen");
            this.oRouter.navTo("detailRemission", { layout: sNextLayout, document: this._document });
        },
        handleClose: function () {
            var sNextLayout = this.oModel.getProperty("/actionButtonsInfo/midColumn/closeColumn");
            this.oRouter.navTo("masterRemission", { layout: sNextLayout });
        },
        _onDocumentMatched: function (oEvent) {
            this._document = oEvent.getParameter("arguments").document || this._document || "0";
            this._lifnr = this.getConfigModel().getProperty("/supplierInputKey");

            var url =
                `/HdrAvisoSet?$expand=EFREMNAV,ETREMDNAV&$filter=IOption eq '2' and ILifnr eq '${this._lifnr}' and IZremision eq '${this._document}'`;
            var dueModel = oModel.getJsonModel(url);

            var ojbResponse = dueModel.getProperty("/results/0");
            //var records = ojbResponse.EDOCDTLNAV;

            this.getOwnerComponent().setModel(new JSONModel(ojbResponse),
                "tableRemissionDetail");

            this.paginate('tableRemissionDetail', '/ETREMDNAV', 1, 0);
        },
        buildExcel: function () {
            var texts = this.getOwnerComponent().getModel("appTxts");
            let Encabezado = this.getOwnerComponent().getModel("tableRemissionDetail");

            var columns = [
                {
                    name: texts.getProperty("/rem.folio"),
                    template: {
                        content: Encabezado.getProperty("/Eremh/Zremision")
                    }
                },
                {
                    name: texts.getProperty("/rem.createDate"),
                    template: {
                        content: Encabezado.getProperty("/Eremh/Zfechrem")
                    }
                },
                {
                    name: texts.getProperty("/rem.destination"),
                    template: {
                        content: Encabezado.getProperty("/Eremh/Werks")
                    }
                },
                {
                    name: texts.getProperty("/rem.typeRemission"),
                    template: {
                        content: Encabezado.getProperty("/Eremh/Ztipoaviso")
                    }
                },
                {
                    name: texts.getProperty("/rem.statusRemission"),
                    template: {
                        content: Encabezado.getProperty("/Eremh/Zstatus")
                    }
                },
                {
                    name: texts.getProperty("/rem.delivdate"),
                    template: {
                        content: Encabezado.getProperty("/Eremh/Zfechem")
                    }
                },
                {
                    name: texts.getProperty("/rem.appointment"),
                    template: {
                        content: Encabezado.getProperty("/Eremh/Zcita")
                    }
                },
                {
                    name: texts.getProperty("/rem.typedeliv"),
                    template: {
                        content: Encabezado.getProperty("/Eremh/Ztipoentreg")
                    }
                },
                {
                    name: texts.getProperty("/rem.countorders"),
                    template: {
                        content: Encabezado.getProperty("/Eremh/Zcantped")
                    }
                },
                {
                    name: texts.getProperty("/rem.packagenumber"),
                    template: {
                        content: Encabezado.getProperty("/Eremh/Zcantbul")
                    }
                },
                {
                    name: texts.getProperty("/rem.order"),
                    template: {
                        content: "{Ebeln}"
                    }
                },
                {
                    name: texts.getProperty("/rem.palletbox"),
                    template: {
                        content: "{Pallet}"
                    }
                },
                {
                    name: texts.getProperty("/rem.codebar"),
                    template: {
                        content: "{Ean11}"
                    }
                },
                {
                    name: texts.getProperty("/rem.description"),
                    template: {
                        content: "{Maktx}"
                    }
                },
                {
                    name: texts.getProperty("/rem.quantity"),
                    template: {
                        content: "{Menge}"
                    }
                },
                {
                    name: texts.getProperty("/rem.uom"),
                    template: {
                        content: "{Bstme}"
                    }
                },
                {
                    name: texts.getProperty("/rem.netcost"),
                    template: {
                        content: "{Bprei}"
                    }
                },
                {
                    name: texts.getProperty("/rem.totalcost"),
                    template: {
                        content: "{Bwert}"
                    }
                },
                {
                    name: texts.getProperty("/rem.currency"),
                    template: {
                        content: "{Waers}"
                    }
                }
            ];

            this.exportxls('tableRemissionDetail', '/ETREMDNAV/results', columns);
        },
        hancleCandel: function (remisionNo) {
            var url = `/HdrAvisoSet?$expand=EFREMNAV,ETREMDNAV&$filter=IOption eq '04' and IZremision eq '${remisionNo}'`;

            var response = oModel.getJsonModel(url);

            if (response != null) {
                var objResponse = response.getProperty("/results/0");
                if (objResponse != null) {
                    if (objResponse.ESuccess == "E") {
                        sap.m.MessageBox.success(this.getOwnerComponent().getModel("appTxts").getProperty("/rem.msgCancelDone"));
                    } else {
                        sap.m.MessageBox.success(objResponse.EMessage);
                    }
                }
            }
        }
    });
});
