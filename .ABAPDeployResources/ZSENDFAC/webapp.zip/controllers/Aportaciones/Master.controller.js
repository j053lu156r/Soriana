sap.ui.define([
    "jquery.sap.global",
    "sap/ui/core/Fragment",
    "demo/controllers/BaseController",
    "sap/m/UploadCollectionParameter",
    "sap/ui/core/mvc/Controller",
    "sap/m/PDFViewer",
    "sap/ui/model/json/JSONModel",
    "sap/ui/core/routing/History",
    "sap/m/MessageBox",
    "sap/ui/core/routing/Router",
    "demo/models/BaseModel",
    'sap/f/library'
], function (jQuery, Fragment, Controller, UploadCollectionParameter, History, PDFViewer, JSONModel, fioriLibrary) {
    "use strict";

    var oModel = new this.Aportaciones();
    return Controller.extend("demo.controllers.Aportaciones.Master", {
        onInit: function () {
            //this.setDaterangeMaxMin();
            this._pdfViewer = new PDFViewer();
            this.getView().addDependent(this._pdfViewer);
            this.getView().addEventDelegate({
                onAfterShow: function (oEvent) {
                    var barModel = this.getOwnerComponent().getModel();
                    barModel.setProperty("/barVisible", true);
                    this.getOwnerComponent().setModel(new JSONModel(), "AportacionesHdr");
                    this.clearFilters();
                }
            }, this);
            this.configFilterLanguage(this.getView().byId("filterBar"));
        },
        searchData: function () {
            var bContinue = true;

            if (!oModel.getModel()) {
                oModel.initModel();
            }

            var vAportacion = this.getView().byId('aportacionInput').getValue();
            var vLifnr = this.getConfigModel().getProperty("/supplierInputKey");
            var texts = this.getOwnerComponent().getModel("appTxts");

            if (bContinue) {

                if(vLifnr == null){
                    vLifnr = "";
                }

                var url = "AportaSet?$expand=AportaDet&$filter=IOption eq '1' and ILifnr eq '" + vLifnr + "'"; // Se debe validar que el usuario este activo
                ;

                if (vAportacion != "") {
                    url += " and IFolio eq '" + vAportacion + "'";
                }

                var dueModel = oModel.getJsonModel(url);

                var ojbResponse = dueModel.getProperty("/results/0");

                console.log(dueModel);

                this.getOwnerComponent().setModel(new JSONModel(ojbResponse),
                    "AportacionesHdr");

                this.paginate("AportacionesHdr", "/ETDEALERSNAV", 1, 0);
            }

        },
        onExit: function () {

        },
        filtrado: function (evt) {
            var filterCustomer = [];
            var query = evt.getParameter("query");
            var obFiltro = this.getView().byId("selectFilter");
            var opFiltro = obFiltro.getSelectedKey();
            if (query && query.length > 0) {
                var filter = new sap.ui.model.Filter(opFiltro, sap.ui.model.FilterOperator.Contains, query);
                filterCustomer.push(filter);
            }

            var list = this.getView().byId("AportacionesHdr");
            var binding = list.getBinding("items");
            binding.filter(filterCustomer);
        },
        setDaterangeMaxMin: function () {
            var datarange = this.getView().byId('dateRange');
            var date = new Date();
            var minDate = new Date();
            var minConsultDate = new Date();
            minConsultDate.setDate(date.getDate() - 7);
            minDate.setDate(date.getDate() - 30);
            datarange.setSecondDateValue(date);
            datarange.setDateValue(minConsultDate);
        },
        onListItemPress: function (oEvent) {
            var resource = oEvent.getSource().getBindingContext("AportacionesHdr").getPath(),
                line = resource.split("/").slice(-1).pop();

            var odata = this.getOwnerComponent().getModel("AportacionesHdr");
            var results = odata.getProperty("/ETDEALERSNAV/Paginated/results");

            var docResult = results[line]; //.campo para obtener el campo deseado            

            this.getOwnerComponent().setModel(new JSONModel(status), "catalogStatus");

            this.createButton(docResult, true);
        },
        clearFilters : function(){
            this.getView().byId("repartidorInput").setValue("");
            this.getView().byId("supplierInput").setValue("");
        },
        buildExportTable: function () {
            var texts = this.getOwnerComponent().getModel("appTxts");
            var columns = [
                 {
                    name: texts.getProperty("/rep.number"),
                    template: {
                        content: "{Usua}"
                    }
                },
                {
                    name: texts.getProperty("/rep.supplier"),
                    template: {
                        content: "{Lifnr}"
                    }
                },
                {
                    name: texts.getProperty("/rep.supplierName"),
                    template: {
                        content: "{Nlifnr}"
                    }
                },
                {
                    name: texts.getProperty("/rep.name"),
                    template: {
                        content: "{Repartidor}"
                    }
                },
                {
                    name: texts.getProperty("/rep.key"),
                    template: {
                        content: "{Clave}"
                    }
                },
                {
                    name: texts.getProperty("/rep.fcad"),
                    template: {
                        content: "{Endda}"
                    }
                },
                {
                    name: texts.getProperty("/rep.status"),
                    template: {
                        content: "{Zactivo}"
                    }
                },                
            ];

            this.exportxls('RepartidoresHdr', '/ETDEALERSNAV/results', columns);
        }

    });
});