sap.ui.define([
    "demo/controllers/BaseController",
    "sap/ui/model/json/JSONModel"
], function (BaseController, JSONModel) {
    "use strict";

    var sUri = "/sap/opu/odata/sap/ZOSP_CATPRO_SRV/";
    

    return BaseController.extend("demo.controllers.Products.Master", {
        onInit: function(){

            this.getView().addEventDelegate({
                onBeforeShow: function (oEvent) {
                    this.getOwnerComponent().setModel(new JSONModel(), "Folios");
                    this.clearFilters();
                }
            }, this);
        },
        searchData: function(){
            var dateRange = this.getView().byId("dateRange");
            //var comboStatus = this.getView().byId("comboStatus");
            var inputFolioTxt = this.getView().byId("inputFolioTxt");


            let folio = inputFolioTxt.getValue().trim();
            //let folio = "0000000943";
            //let status = comboStatus.getSelectedKey();
            //let status = 'A';

            //let proveedor_LIFNR = 21;
            let proveedor_LIFNR = (this.getConfigModel().getProperty("/supplierInputKey") != undefined) ? this.getConfigModel().getProperty("/supplierInputKey") : '';
            // format[AAAAMMDD] (2020101)
            let IStartdate = this.buildSapDate(dateRange.getDateValue());
            // format[AAAAMMDD] (2020101)
            let IEnddate = this.buildSapDate(dateRange.getSecondDateValue());
            //let IIdusua = this.getOwnerComponent().getModel("userdata").getProperty('/EIdusua');
            //let IIdusua = '';
            //console.log(this.getOwnerComponent().getModel("userdata").getJSON());

            if (folio.trim() === '' && proveedor_LIFNR == '' && dateRange.getValue() == '' ) {
                sap.m.MessageBox.error(this.getOwnerComponent().getModel("appTxts").getProperty('/products.msgNoFilter'));
                return false;
            }



            let filtros = [`IOption eq '2'`];

            filtros.push(`IUniqr eq '${folio}'`);

            if( folio != '' ){
                filtros.push(`ISdate eq '' and IFdate eq ''`);
            }
            else{
                filtros.push(`ISdate eq '${IStartdate}' and IFdate eq '${IEnddate}'`);
                // if (status != '') filtros.push(`IStatus eq '${status}'`);
            }
            
            // if (String(IIdusua).trim() != '') filtros.push(`IIdusua eq '${IIdusua}'`);
            
            //if (proveedor_LIFNR != '' && !this.getView().byId("colSor").getSelected() ) 
            filtros.push(`ILifnr eq '${proveedor_LIFNR}'`);
            

            filtros = filtros.join(' and ');

            // let url = `HeaderPYMNTCSet?$expand=EPYMNTDOCSNAV,EPYMNTPRGRMNAV&$filter= IOption eq '2' and ILifnr eq '${proveedor_LIFNR}' and IStartdate eq '${IStartdate}'  and IEnddate eq '${IEnddate}'&$format=json`;
            let url = `HdrcatproSet?$expand=ETPRICNAV&$filter=${filtros}&$format=json`;


            let oODataJSONModel = this.getOdata(sUri);

            let oDataJSONModel = this.getOdataJsonModel(url, oODataJSONModel);
            let dataJSON = oDataJSONModel.getJSON();
            let Datos = JSON.parse(dataJSON);

            // console.log(Datos);

            this.getOwnerComponent().setModel(new JSONModel(Datos.results[0]), "Folios");

            this.paginate("Folios", "/ETPRICNAV", 1, 0);
        },
        clearFilters: function(){
            
        },
        paginar : function(selectedItem){
                
            let totalRegistros = parseInt( this.getOwnerComponent().getModel('Folios').getProperty('/ETPRICNAV/results/length'), 10);
            let valorSeleccinado = parseInt( selectedItem.getKey(), 10);
            
            let tablaPrincipal = this.getView().byId("foliosList");
            tablaPrincipal.setVisibleRowCount( totalRegistros < valorSeleccinado ? totalRegistros : valorSeleccinado );
            this.paginateValue(selectedItem, 'Folios', '/ETPRICNAV');
        },
        buildExportTable: function () {
            var texts = this.getOwnerComponent().getModel("appTxts");

            var columns = [
                {
                    name: texts.getProperty("/products.folioUPC"),
                    template: {
                        content: "{UniqueReference}"
                    }
                },
                {
                    name: texts.getProperty("/products.productUPC"),
                    template: {
                        content: "{EanUpcBase}"
                    }
                },
                {
                    name: texts.getProperty("/products.descriptionUPC"),
                    template: {
                        content: "{HazardDescript}"
                    }
                },
                {
                    name: texts.getProperty("/products.typeUPC"),
                    template: {
                        content: "{Zzstatus}"
                    }
                },
                {
                    name: texts.getProperty("/products.dateUPC"),
                    template: {
                        content: "{ValidityBase}"
                    }
                },
                {
                    name: texts.getProperty("/products.dateStatusUPC"),
                    template: {
                        content: "{TakeOverDate}"
                    }
                },
                {
                    name: texts.getProperty("/products.statusUPC"),
                    template: {
                        content: "{ProcStatus}"
                    }
                },
                {
                    name: texts.getProperty("/products.descriptionStatusUPC"),
                    template: {
                        content: "{Pristate}"
                    }
                }
            ];

            this.exportxls('Folios', '/ETPRICNAV/results', columns);
        },
    })
});