function initModel() {
	
}